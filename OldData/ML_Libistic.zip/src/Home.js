import React from 'react';

const Home = (props) => (
  
    <div className='Page'>
           
        </div>
)

export default Home;