import React from 'react';
 import { Nav, Navbar,Form, FormControl } from 'react-bootstrap';
import styled from 'styled-components';
import logo from './img/logo.png';

const Styles = styled.div`
  #logo{
    margin-left:40px;
    height:15vh;
    weight:15vw;
  }
  .navbar { background-color: white; }
  .nav-link {
    position:relative;
    right:250px;
    margin-right:80px;
  }
  a, .navbar-nav, .navbar-light .nav-link {
    font-size:22px;
    color: gray;
    &:hover { color: black; }
  }
  .navbar-brand {
    font-size: 2em;
    color: rgb(69, 131, 212);;
    &:hover { color: black; }
  }
`;
const NavigationBar = () => (
  <Styles>
    <Navbar expand="lg">
      <Navbar.Brand href="#"><img id='logo' src={logo} alt='Libistic' /></Navbar.Brand>
      <Navbar.Toggle aria-controls="basic-navbar-nav"/>
      <Navbar.Collapse id="basic-navbar-nav">
        <Nav className="ml-auto" ></Nav>
        <Nav.Item><Nav.Link href='/' >Home</Nav.Link></Nav.Item>
          <Nav.Item><Nav.Link href= "/Seats" >Seats</Nav.Link></Nav.Item>
          <Nav.Item><Nav.Link href= "/Booking">Booking</Nav.Link></Nav.Item>
      </Navbar.Collapse>
      <Form className="form-center">
        <FormControl type="text" placeholder="Search" className="" />
      </Form>
      
    </Navbar>
  </Styles>
)

export default NavigationBar;