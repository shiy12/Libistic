import React from 'react';
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

import './App.css';
import NavigationBar from './Navigation';
import Home from './Home';
import Booking from './Booking';
import Seats from './Seats';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

class App extends React.Component {

  render() {
    
    return (
      <div >
        <React.Fragment>
          <Router>
            <NavigationBar />
            <Switch>
                <Route path="/" component={Home} exact />
                <Route path="/Seats" component={Seats} />
                <Route path="/Booking" component={Booking} />
          </Switch>
          </Router>
        </React.Fragment>
      </div>
      
    );
  }
}

export default App;
